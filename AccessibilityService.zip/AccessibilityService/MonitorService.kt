package com.example.accessibilityservice

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.io.File
import java.io.FileOutputStream

class MonitorService : AccessibilityService() {

    private var keywords = listOf("paused", "retrying", "connect error", "failed", "timeout")
    private val keywordsFile = File("/sdcard/retry_keywords.txt")

    override fun onServiceConnected() {
        super.onServiceConnected()
        loadKeywords()
    }

    private fun loadKeywords() {
        if (keywordsFile.exists()) {
            keywords = keywordsFile.readLines()
                .map { it.trim().lowercase() }
                .filter { it.isNotEmpty() }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString()
        if (pkg != "idm.internet.download.manager") return

        val root = rootInActiveWindow ?: return
        val data = StringBuilder()

        findText(root, Regex(".*\\d+\\.?\\d*\\s*(KB/s|MB/s|B/s)", RegexOption.IGNORE_CASE))
            ?.let { data.append("SPEED=$it\n") }

        findText(root, Regex("retrying\\s*\\(\\d+\\)", RegexOption.IGNORE_CASE))
            ?.let { data.append("RETRY=$it\n") }

        for (kw in keywords) {
            findText(root, Regex(kw, RegexOption.IGNORE_CASE))?.let {
                data.append("ERROR_MESSAGE=$it\n")
                break
            }
        }

        findButtonByContentDesc(root, "More options")?.let { bounds ->
            data.append("MENU_BUTTON=${bounds[0]},${bounds[1]},${bounds[2]},${bounds[3]}\n")
        }

        findButtonByText(root, "DOWNLOADING")?.let { bounds ->
            data.append("DOWNLOADING_TAB=${bounds[0]},${bounds[1]},${bounds[2]},${bounds[3]}\n")
        }

        val items = findProblemItems(root, keywords)
        items.forEachIndexed { idx, (name, bounds) ->
            data.append("PAUSED_ITEM_$idx=$name|${bounds[0]},${bounds[1]},${bounds[2]},${bounds[3]}\n")
        }

        File("/sdcard/1dm_data.txt").writeText(data.toString())
    }

    private fun findText(node: AccessibilityNodeInfo, pattern: Regex): String? {
        val text = node.text?.toString() ?: ""
        if (pattern.matches(text)) return text
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { findText(it, pattern) }?.let { return it }
        }
        return null
    }

    private fun findButtonByContentDesc(node: AccessibilityNodeInfo, desc: String): IntArray? {
        if (node.contentDescription?.toString() == desc && node.isClickable) {
            val rect = Rect()
            node.getBoundsInScreen(rect)
            return intArrayOf(rect.left, rect.top, rect.right, rect.bottom)
        }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { findButtonByContentDesc(it, desc) }?.let { return it }
        }
        return null
    }

    private fun findButtonByText(node: AccessibilityNodeInfo, text: String): IntArray? {
        if (node.text?.toString() == text && node.isClickable) {
            val rect = Rect()
            node.getBoundsInScreen(rect)
            return intArrayOf(rect.left, rect.top, rect.right, rect.bottom)
        }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { findButtonByText(it, text) }?.let { return it }
        }
        return null
    }

    private fun findProblemItems(root: AccessibilityNodeInfo, keywords: List<String>): List<Pair<String, IntArray>> {
        val results = mutableListOf<Pair<String, IntArray>>()
        val allNodes = mutableListOf<AccessibilityNodeInfo>()
        collectAllNodes(root, allNodes)

        val problemRows = mutableSetOf<AccessibilityNodeInfo>()
        for (node in allNodes) {
            val text = node.text?.toString()?.lowercase() ?: ""
            if (keywords.any { text.contains(it) }) {
                var row = node
                while (row.parent != null && row.parent.getBoundsInScreen().width() > 200) {
                    row = row.parent
                }
                problemRows.add(row)
            }
        }

        for (row in problemRows) {
            val rect = Rect()
            row.getBoundsInScreen(rect)
            val filename = findFilenameInRow(row) ?: "unknown"
            results.add(Pair(filename, intArrayOf(rect.left, rect.top, rect.right, rect.bottom)))
        }
        return results
    }

    private fun collectAllNodes(node: AccessibilityNodeInfo, list: MutableList<AccessibilityNodeInfo>) {
        list.add(node)
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { collectAllNodes(it, list) }
        }
    }

    private fun findFilenameInRow(row: AccessibilityNodeInfo): String? {
        val candidates = mutableListOf<String>()
        findTexts(row, candidates)
        return candidates.firstOrNull { it.contains('.') || it.length > 10 }
    }

    private fun findTexts(node: AccessibilityNodeInfo, list: MutableList<String>) {
        node.text?.toString()?.let { list.add(it) }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { findTexts(it, list) }
        }
    }

    override fun onInterrupt() {}
}